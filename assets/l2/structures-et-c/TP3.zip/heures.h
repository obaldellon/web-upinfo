#ifndef _HEURES_H
#define _HEURES_H

#define HEURES 24
#define MINUTES 60
#define SECONDES 60

struct heure {
	short h; /* les heures 0 .. HEURES-1 */
	short m; /* les minutes 0 .. MINUTES-1 */
	short s; /* les secondes 0 .. SECONDES-1 */ 
};
typedef struct heure Heure;

typedef enum {syst24, syst12} Systeme;
/* syst24 = syst�me 24h, syst12 = syst�me 12h (am, pm) */

Heure heureLocale (void);
/* R�le : renvoie l'heure actuelle de la machine sur laquelle
tourne l'ex�cutable */
/* POUR L'INSTANT, VOUS RENVOYEZ 0h0mn0s: VOUS REGARDEREZ LA SOLUTION */

Heure saisirHeure (void);
/* R�le : renvoie l'heure lue sur l'entr�e standard en syst�me 24h
(les champs respectent les contraintes) */

Heure mettreHeure (short h, short m, short s);
/* R�le : renvoie l'heure � partir des donn�es transmises en param�tres,
et si les donn�es ne respectent pas les contraintes, renvoie 0h0mn0s */

void afficherHeure (Heure h, Systeme s);
/* Ant�c�dent : h heure valide */
/* R�le : �crit sur la sortie standard l'heure h sous la forme du syst�me s */

long int heure2sec (Heure h);
/* Ant�c�dent : h heure valide */
/* R�le : renvoie le nombre de secondes correspondant � l'heure h */

Heure sec2heure (long int s);
/* R�le : renvoie l'heure correspondant au nombre de secondes
(0h0mn0s si probl�me) */

Heure ajouterHeure (Heure h1, Heure h2);
/* Ant�c�dent : h1 et h2 heures valides */
/* R�le : renvoie h1 + h2 */

Heure soustraireHeure (Heure h1, Heure h2);
/* Ant�c�dent : h1 et h2 heures valides */
/* R�le : renvoie h1 - h2 */

#endif
