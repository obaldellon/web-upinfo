#include <stdio.h>

#define ADRCHAMPS(v) \
	printf("   .e = %d\n", (int)&v.e); \
	printf("   .r = %d\n", (int)&v.r); \
	printf("   .t = %d\n", (int)&v.t); \
	printf("   .s = %d\n", (int)&v.s); \
	printf("   .c = %d\n", (int)&v.c); \


struct idiote {
	int e;
	double r;
	int t[10];
	char *s;
	char c;
};

int main (int argc, char *argv[]) {
	struct idiote v1, v2;

	printf("sizeof(struct idiote) = %d octets\n",sizeof(struct idiote));
	printf("somme de la taille des champs = %d\n\n",sizeof v1.e + sizeof v1.r + sizeof v1.t + sizeof v1.s + sizeof v1.c);
	printf("&v1   = %d\n", (int)&v1);
	ADRCHAMPS(v1);
	printf("\n&v2   = %d\n", (int)&v2);
	ADRCHAMPS(v2);
	printf("\n&v1-&v2 = %d\n", (int)&v1 - (int)&v2);
	return 0;
}
