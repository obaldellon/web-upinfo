#ifndef _CHAINES_H
#define _CHAINES_H

int longueur (const char s[]);
  /* Ant�c�dent : s doit �tre une cha�ne � la C */
  /* R�le : renvoie la longueur de s */

char *copieChaine (const char s[]);
  /* Ant�c�dent : s doit �tre une cha�ne � la C */
  /* R�le : renvoie une copie de s */

char *concateneChaines (const char s1[], const char s2[]);
  /* Ant�c�dent : s1 et s2 doivent �tre des cha�nes � la C */
  /* R�le : renvoie s1 + s2 */

char *miseEnMajuscules (const char s[]);
  /* Ant�c�dent : s doit �tre une cha�ne � la C */
  /* R�le : renvoie une copie de s dont les caract�res sont en majuscules */

int compareChaines (const char s1[], const char s2[]);
  /* Ant�c�dent : s1 et s2 doivent �tre des cha�nes � la C */
  /* R�le : renvoie un nombre positif si s1 > s2, 0 si s1 = s2, un nombre
     n�gatif sinon */

#endif

