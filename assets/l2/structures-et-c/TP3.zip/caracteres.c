#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void affCar (char c) {
	printf("%c\n", c);
}

void majCar (char c) {
	c = toupper(c);
}

int majCarF (char c) {
	return toupper(c);
}

void majCarP (char *c) {
	printf("1 dans majCarP, c = %p, *c = %c\n", c, *c);
	*c = toupper(*c);
	printf("2 dans majCarP, c = %p, *c = %c\n", c, *c);
}

void majCarPbis (char *c) {
	printf("1 dans majCarPbis, c = %p, *c = %c\n", c, *c);
	c = malloc(sizeof(char));
	*c = 'a';
	printf("2 dans majCarPbis, c = %p, *c = %c\n", c, *c);
}

int main (int argc, char *argv[]) {
	char car = 'b';

	affCar(car);
	majCar(car); affCar(car);
	affCar(majCarF(car)); affCar(car);
	majCarP(&car); affCar(car);
	majCarPbis(&car); affCar(car);
	return 0;
}
