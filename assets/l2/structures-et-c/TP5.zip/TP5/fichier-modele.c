#include <stdlib.h>

#include "fichier.h"

#ifdef SELFEXEC
int main (int argc, char * argv[]) {
	/* argv[1] est le nom du fichier */
	fichier fic;
	tableau tab;

	if (argc != 2) {
		fprintf(stderr, "usage: %s filename\n", argv[0]);
		return 1;
	}

	/* création du fichier si nécessaire */
	if ((fic = fopen(argv[1], "rb")) == NULL) {
		printf("le fichier %s n'existe pas, il faut le créer\n",argv[1]);
		if ((fic = fopen(argv[1], "wb")) == NULL) {
			fprintf(stderr, "ouverture du fichier %s impossible en écriture\n",argv[1]);
			return 2;
		}
		{
			int nb;

			printf("Nombre d'éléments du tableau à créer? ");
			scanf("%d", &nb);
			creerFichier(fic, nb);
		}
		fclose(fic);
		fic = fopen(argv[1], "rb");
	}

	/* on lit le fichier et on sauvegarde les éléments dans un tableau */
	printf("lecture du fichier et svg dans un tableau:\n");
	tab = fichier2tableau(fic);

	/* affichage des éléments du tableau */
	printf("affichage des éléments du tableau:\n");
	afficherTableau(tab, afficherElement);

	{
		char cmd[100];

#include <ctype.h>
#include <string.h>

		/* on efface le fichier si l'utilisateur le veut */
		do {
			printf("effacement du fichier %s (Oo/Nn)?", argv[1]);
			fgets(cmd, sizeof cmd, stdin);
			cmd[0] = toupper(cmd[0]);
			if (!strcmp(cmd, "N\n"))
				return 0;
		}
		while (strcmp(cmd, "O\n"));
		sprintf(cmd, "rm -f %s", argv[1]);
		system(cmd);
	}

	return 0;
}
#endif
