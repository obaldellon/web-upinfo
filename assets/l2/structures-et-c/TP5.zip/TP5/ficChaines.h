#ifndef _FICCHAINES_H
#define _FICCHAINES_H

typedef struct {
  char *nom;
  unsigned short age;
} personne;

#endif
