#ifndef _FICHIER_H
#define _FICHIER_H

#include <stdio.h>

/* Le type des éléments du tableau */
typedef int element;

/* la structure du tableau :
 * un champ indiquant le nombre d'éléments
 * un champ qui est le tableau lui-même
 */
typedef struct {
    unsigned int nb; /* le nombre d'éléments effectifs */
    element *t; /* les éléments eux-mêmes */
} tableau;

/* le type du fichier */
typedef FILE * fichier;

/* le nombre d'éléments à allouer au fur et à mesure */
#define NB 10


/* Écrit sur la sortie standard l'élément e */
void afficherElement (element e);

/* Renvoie un élément tiré au hasard */
element elementAuHasard (void);

/* Écrit sur la sortie standard tous les éléments du tableau t
 * (chaque élément étant séparé par un blanc) grâce à la procédure p
 * (qui permet d'écrire un élément sur la sortie standard) 
 */
void afficherTableau (tableau t, void (*p) (element));

/* Crée un fichier de n éléments tirés au hasard */
void creerFichier (fichier f, int n);

/* Renvoie un tableau contenant les éléments du fichier f;
 * la taille du tableau est un multiple de NB mais certaines
 * cases peuvent être vides... (allocation au fur et à mesure);
 * le nombre d'éléments du tableau est le nombre d'éléments effectifs
 */
tableau fichier2tableau (fichier f);

#endif
