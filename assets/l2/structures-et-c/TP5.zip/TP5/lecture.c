#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEFAUT 10

int main (int argc, char *argv[]) {
  int nbcar;
  char *tampon;

  if (argc != 2) {
    fprintf(stderr, "usage: %s nb>0\n%d pris par défaut\n", argv[0], DEFAUT);
    nbcar = DEFAUT;
  }
  else if ((nbcar = atoi(argv[1])) == 0) {
    fprintf(stderr, "usage: %s nb>0\n%d pris par défaut\n", argv[0], DEFAUT);
    nbcar = DEFAUT;
  }
  /* allocation de la mémoire */
  tampon = malloc((nbcar+1) * sizeof(char));
  if (!tampon) {
    fprintf(stderr, "erreur d'allocation...\n");
    exit(2);
  }
  printf("Entrez une chaîne de %d caractères maxi? ", nbcar);
  fgets(tampon, nbcar+1, stdin);
  printf("chaîne lue *%s*\n", tampon);
   /* le problème est que le retour-chariot est peut-être dans la chaîne... */
  {
    char *p = strchr(tampon, '\n');
    if (p) *p = '\0';
  }

  printf("chaîne lue *%s*\n", tampon);

  printf("Entrez une 2e chaîne de %d caractères maxi? ", nbcar);
  fgets(tampon, nbcar+1, stdin);
  printf("\n2e chaîne lue *%s*\n", tampon);
  return 0;
}
