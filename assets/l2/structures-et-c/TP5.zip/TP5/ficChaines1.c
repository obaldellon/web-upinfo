#include <stdio.h>
#include <stdlib.h>

#include "ficChaines.h"

int main (int argc, char *argv[]) {
  personne enfants[4];
  FILE *f = fopen("noms", "w");

  if (f == NULL) {
    fprintf(stderr, "erreur d'ouverture en écriture du fichier noms\n");
    return 1;
  }
  enfants[0].nom = "Maud"; enfants[0].age = 5;
  enfants[1].nom = "Lisa"; enfants[1].age = 9;
  enfants[2].nom = "Romain"; enfants[2].age = 10;
  enfants[3].nom = "Guillaume"; enfants[3].age = 2;
  fwrite(enfants, sizeof(personne), 4, f);
  fclose(f);

  printf("pour essayer de comprendre:\n");
  printf("sizeof(char *) = %lu\n", sizeof(char *));
  printf("sizeof(char [256]) = %lu\n", sizeof(char [256]));
  printf("sizeof(unsigned short) = %lu\n", sizeof(unsigned short));
  printf("sizeof(personne) = %lu\n", sizeof(personne));
  system("ls -l noms");
  return 0;
}

