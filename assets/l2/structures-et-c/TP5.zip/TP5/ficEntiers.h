#ifndef _FICENTIERS_H
#define _FICENTIERS_H

#include <stdio.h>

/* Rôle : ouvre le fichier physique nom en lecture et renvoie le
   descripteur de fichier logique correspondant */
FILE *ouvrirEnLecture (char *nom);

/* Antécédent : fd ouvert en lecture */
/* Rôle : si en fin de fichier, renvoie 0
   sinon, renvoie != 0 et *a contient le prochain élément du fichier
   décrit par  fd */
int lireUnEntier (FILE *fd, int *a);

/* Rôle : ouvre le fichier physique nom en écriture et renvoie le
   descripteur de fichier logique correspondant */
FILE *ouvrirEnEcriture (char *nom);

/* Antécédent : fd ouvert en écriture */
/* Rôle : si pb d'écriture, renvoie 0
   sinon, renvoie 1 et *a a été écrit à la suite dans le fichier
   décrit par fd */
int ecrireUnEntier (FILE *fd, int *a);

/* Antécédent : fichier décrit par fd ouvert */
/* Rôle : ferme le fichier décrit par fd */
void fermer (FILE *fd);

#endif
