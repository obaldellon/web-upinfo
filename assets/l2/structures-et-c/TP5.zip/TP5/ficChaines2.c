#include <stdio.h>

#include "ficChaines.h"

int main (int argc, char *argv[]) {
  personne enfants[4];
  FILE *f = fopen("noms", "r");
  int i, nb;

  if (f == NULL) {
    fprintf(stderr, "erreur d'ouverture en lecture du fichier noms\n");
    return 1;
  }
  nb =  fread(enfants, sizeof(personne), 4, f);
  for (i = 0; i < nb; i++)
    fprintf(stdout, "L'enfant %s a %d ans\n", enfants[i].nom,
	    enfants[i].age);
  fclose(f);
  return 0;
}

