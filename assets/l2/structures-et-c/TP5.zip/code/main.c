#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "ficEntiers.h"

int main (int argc, char *argv[]) {
	int nb;
	char *nomFic;
	char cmd[100]; /* pour la fonction system qui permet d'ex�cuter
				   un ordre Shell (pass� en param�tre) */

	if (argc == 1) {
		/* tout est par d�faut */
		nb = 10;
		nomFic = "./fic";
	}
	else if (argc != 3) {
		fprintf(stderr, "usage: %s [nb filename]\n", argv[0]);
		exit(3);
	}
	else {
		nb = atoi(argv[1]);
		nomFic = argv[2];
	}

	{
		/* cr�ation du fichier */
		FILE *fe = ouvrirEnEcriture(nomFic);
		int i, elem;

		printf("cr�ation du fichier %s, avec %d entiers:\n", nomFic, nb);
		for (i = 0; i < nb; i++) {
			printf("entier? ");
			scanf("%d", &elem);
			if (!ecrireUnEntier(fe, &elem))
				fprintf(stderr, "pb d'�criture de %d dans le fichier %s\n",
				elem, nomFic);
		}
		fermer(fe);
		printf("sizeof(int) = %d\n", sizeof(int));
		/* on affiche la taille du fichier */
		sprintf(cmd, "ls -l %s", nomFic);
		system(cmd);
	}
	{
		/* lecture du fichier cr�� */
		FILE *fl = ouvrirEnLecture(nomFic);
		int elem;

		printf("\n\nlecture � normale � du fichier %s et affichage de ses �l�ments:\n", nomFic);
		while (lireUnEntier(fl, &elem)){
			fprintf(stdout, "%d ", elem);
		}
		fputc('\n', stdout);
		fermer(fl);
	}
	{
		/* autre lecture du fichier cr�� */
		FILE *fl = ouvrirEnLecture(nomFic);
		int c;

		printf("\n\nlecture du fichier %s octet par octet et affichage:\n",nomFic);
		while ((c = fgetc(fl)) != EOF){
			if (isprint(c))
				printf("%c ", c);
			else
				fputc('.', stdout);
		}
		fputc('\n', stdout);
		fermer(fl);
	}
	/* on efface le fichier cr��: */
	sprintf(cmd, "rm -f %s", nomFic);
	system(cmd);
	return 0;
}
