#include <stdlib.h>

#include "fichier.h"

void afficherElement (element e) {
    /* �crit sur la sortie standard l'�l�ment e */
    ...
}

element elementAuHasard (void) {
    /* renvoie un �l�ment tir� au hasard */
    ...
}

void afficherTableau (tableau t, void (*p) (element)) {
    /* �crit sur la sortie standard tous les �l�ments du tableau t
       (chaque �l�ment �tant s�par� par un blanc) gr�ce � la proc�dure p
       (qui permet d'�crire un �l�ment sur la sortie standard) */
    ...
}

void creerFichier (fichier f, int n) {
    /* cr�e un fichier de n �l�ments tir�s au hasard */
    ...
}

tableau fichier2tableau (fichier f) {
    /* renvoie un tableau contenant les �l�ments du fichier f;
       la taille du tableau est un multiple de NB mais certaines
       cases peuvent �tre vides... (allocation au fur et � mesure);
       le nombre d'�l�ments du tableau est le nombre d'�l�ments effectifs
    */
    ...
}

#ifdef SELFEXEC
int main (int argc, char * argv[]) {
	/* argv[1] est le nom du fichier */
	fichier fic;
	tableau tab;

	if (argc != 2) {
		fprintf(stderr, "usage: %s filename\n", argv[0]);
		return 1;
	}

	/* cr�ation du fichier si n�cessaire */
	if ((fic = fopen(argv[1], "rb")) == NULL) {
		printf("le fichier %s n'existe pas, il faut le cr�er\n",argv[1]);
		if ((fic = fopen(argv[1], "wb")) == NULL) {
			fprintf(stderr, "ouverture du fichier %s impossible en �criture\n",argv[1]);
			return 2;
		}
		{
			int nb;

			printf("Nombre d'�l�ments du tableau � cr�er? ");
			scanf("%d", &nb);
			creerFichier(fic, nb);
		}
		fclose(fic);
		fic = fopen(argv[1], "rb");
	}

	/* on lit le fichier et on sauvegarde les �l�ments dans un tableau */
	printf("lecture du fichier et svg dans un tableau:\n");
	tab = fichier2tableau(fic);

	/* affichage des �l�ments du tableau */
	printf("affichage des �l�ments du tableau:\n");
	afficherTableau(tab, afficherElement);

	{
		char cmd[100];

#include <ctype.h>
#include <string.h>

		/* on efface le fichier si l'utilisateur le veut */
		do {
			printf("effacement du fichier %s (Oo/Nn)?", argv[1]);
			fgets(cmd, sizeof cmd, stdin);
			cmd[0] = toupper(cmd[0]);
			if (!strcmp(cmd, "N\n"))
				return 0;
		}
		while (strcmp(cmd, "O\n"));
		sprintf(cmd, "rm -f %s", argv[1]);
		system(cmd);
	}

	return 0;
}
#endif
