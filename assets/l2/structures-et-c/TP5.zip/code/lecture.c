#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DEFAUT 10

int main (int argc, char *argv[]) {
  int nbcar;
  char *tampon;

  if (argc != 2) {
    fprintf(stderr, "usage: %s nb>0\n%d pris par d�faut\n", argv[0], DEFAUT);
    nbcar = DEFAUT;
  }
  else if ((nbcar = atoi(argv[1])) == 0) {
    fprintf(stderr, "usage: %s nb>0\n%d pris par d�faut\n", argv[0], DEFAUT);
    nbcar = DEFAUT;
  }
  /* allocation de la m�moire */
  tampon = malloc((nbcar+1) * sizeof(char));
  if (!tampon) {
    fprintf(stderr, "erreur d'allocation...\n");
    exit(2);
  }
  printf("Entrez une cha�ne de %d caract�res maxi? ", nbcar);
  fgets(tampon, nbcar+1, stdin);
  printf("cha�ne lue *%s*\n", tampon);
   /* le probl�me est que le retour-chariot est peut-�tre dans la cha�ne... */
  {
    char *p = strchr(tampon, '\n');
    if (p) *p = '\0';
  }

  printf("cha�ne lue *%s*\n", tampon);

  printf("Entrez une 2e cha�ne de %d caract�res maxi? ", nbcar);
  fgets(tampon, nbcar+1, stdin);
  printf("\n2e cha�ne lue *%s*\n", tampon);
  return 0;
}
