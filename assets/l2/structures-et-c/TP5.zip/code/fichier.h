#ifndef _FICHIER_H
#define _FICHIER_H

#include <stdio.h>

/* le type des �l�ments du tableau */
typedef int element;

/* la structure du tableau :
   un champ indiquant le nombre d'�l�ments
   un champ qui est le tableau lui-m�me
*/
typedef struct {
    unsigned int nb; /* le nombre d'�l�ments effectifs */
    element *t; /* les �l�ments eux-m�mes */
} tableau;

/* le type du fichier */
typedef FILE * fichier;

/* le nombre d'�l�ments � allouer au fur et � mesure */
#define NB 10

#endif
