#ifndef _FICENTIERS_H
#define _FICENTIERS_H

#include <stdio.h>

FILE *ouvrirEnLecture (char *nom);
/* R�le : ouvre le fichier physique nom en lecture et renvoie le
   descripteur de fichier logique correspondant */

int lireUnEntier (FILE *fd, int *a);
/* Ant�c�dent : fd ouvert en lecture */
/* R�le : si en fin de fichier, renvoie 0
   sinon, renvoie != 0 et *a contient le prochain �l�ment du fichier
   d�crit par  fd */

FILE *ouvrirEnEcriture (char *nom);
/* R�le : ouvre le fichier physique nom en �criture et renvoie le
   descripteur de fichier logique correspondant */

int ecrireUnEntier (FILE *fd, int *a);
/* Ant�c�dent : fd ouvert en �criture */
/* R�le : si pb d'�criture, renvoie 0
   sinon, renvoie 1 et *a a �t� �crit � la suite dans le fichier
   d�crit par fd */

void fermer (FILE *fd);
/* Ant�c�dent : fichier d�crit par fd ouvert */
/* R�le : ferme le fichier d�crit par fd */

#endif
